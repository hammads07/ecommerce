var dt = new Date();
document.getElementById('date-time').innerHTML=dt;